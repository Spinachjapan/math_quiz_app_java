/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NetworkedMathQuiz_gui;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;


public class sort {
    
    
    private String [][] sortedList;
    
    
    
    public sort (String sortType, ArrayList<Questions> Questions)
    {
    
        Questions memo;
        
        
        if (sortType.equals("bubble"))
        {
        
        boolean bubble_flag = false;
        

        
        while (!bubble_flag)  
        {
       bubble_flag = true;
        for (int i = 0; i < Questions.size() - 1; i++) {
            
            //
            //System.out.println(Questions.get(i).compareTo(Questions.get(i+1)));
            
            
            if (Questions.get(i).compareTo(Questions.get(i+1)) == 1) {
                
                memo = Questions.get(i);
                Questions.set(i, Questions.get(i+1));
                
                Questions.set(i+1, memo);
                bubble_flag = false;
            }
       
        
        }
        
        
        
        }
        
        }
        
        
        
        if (sortType.equals("selection"))
        {
        
            
            
        for (int i = 0; i < Questions.size(); i++) {
            
            int maximum = i;
            
            
            
            
            for (int j = i + 1; j < Questions.size(); j++) 
            {
                if (Questions.get(j).compareTo(Questions.get(i)) == 1) {
                maximum = j;
            }
            }
        
            memo = Questions.get(i);
            Questions.set(i, Questions.get(maximum));
            Questions.set(maximum, memo);
        
            
       
        }
        
    
    
    }
    
    
        
        
         if (sortType.equals("insertion"))
        {
        
            
            
        for (int i = 1; i < Questions.size(); i++) 
        {
          //System.out.println("i: " + Questions.get(i));
            for (int j = 0; j < i; j++) 
            {
           
                
                if (Questions.get(j).compareTo(Questions.get(i)) == 1)
                {
                
                memo = Questions.get(j);
                Questions.set(j, Questions.get(i));
                Questions.set(i, memo);
                
                
                
                }
                
            
            
            }
          
        
        
            
       
        }
        
    
    
    }
        
    
         
   sortedList = new String[Questions.size()][];        
   int counter = 0;
  for (int i=0; i < Questions.size(); i++)      
  {
      
      String [] eachRow = new String[5];
      
      eachRow[0] = Questions.get(i).first_number;
      eachRow[1] = Questions.get(i).operator;
      eachRow[2] = Questions.get(i).second_number;
      eachRow[3] = "=";
      eachRow[4] = String.valueOf(Questions.get(i).answer);
   
      sortedList[counter] = eachRow;
      counter++;
  }   
       
        
   
}

    public Object[][] getResult()
    {
        
  
    return sortedList;
    
    }
    
    
    
    
    
}
