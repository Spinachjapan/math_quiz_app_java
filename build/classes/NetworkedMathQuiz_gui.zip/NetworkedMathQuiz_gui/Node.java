/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NetworkedMathQuiz_gui;

/**
 *
 * @author kipposhi
 */
import java.util.Comparator;


public class Node<T extends Comparable <T>> implements Comparable<Node<T>>
{
    // data component
    public T data;
    // reference to the left child node (a memory address)
    public Node<T> leftChild;
    // reference to the right child node (a memory address)
    public Node<T> rightChild;

    // constructor method for Node()
    // initialise data
    // set right and left child nodes to null
    public Node(T data)
    {
        // when initialised, this default constructor sets up the input data
        // to get assigned to the new object's data
        // the references for the left and right child nodes are made null
        // as none exist at this point
        this.data = data;
        leftChild = null;
        rightChild = null;
    }
    
    @Override
    public String toString()
    {
        return data.toString();
    }

    
    
    // implement compareTo() method
    public int compareTo (Node <T> otherNode)
    {
        // use Comparable interface built-in compareTo() method
        // returns  0 if this.data == otherNode.data
        // returns -1 if this.data < otherNode.data
        // returns  1 if this.data > otherNode.data
        return this.data.compareTo(otherNode.data);
    }
    
}